package data_analyzer;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;

public class Datahandler implements MqttCallback {

    final static String serverURL = "http://172.28.1.3:8086";

    final private static String username_influx = "admin";
    private static String password_influx = "admin123";
    final private InfluxDB influxDB = InfluxDBFactory.connect(serverURL, username_influx, password_influx);
    final private static String databaseName = "weatherDB";

    private static String topic = "htl/ws/#";
    private static String broker = "tcp://iotmqtt.htl-klu.at";
    private static String clientId = "dataAnalyzer";
    private static String username_mqtt = "htl-IoT";
    private static String password_mqtt = "iot..2015";
    private static MemoryPersistence persistence = new MemoryPersistence();
    private static MqttClient sampleClient;

    private static String regex = "[-+]?([0-9]*\\.[0-9]+|[0-9]+)";

    public Datahandler(String sub) {
        try {
            influxDB.setDatabase(databaseName);
            sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            connOpts.setUserName(username_mqtt);
            connOpts.setPassword(password_mqtt.toCharArray());

            sampleClient.setCallback(this);

            System.out.println("Connecting to broker: " + broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");

            sampleClient.subscribe(sub);


        } catch (MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Datahandler object = new Datahandler(topic);
    }

    @Override
    public void connectionLost(Throwable cause) {
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) {
        String[] topic_split = topic.split("/");
        String messageToCheck = new String(message.getPayload());

        if (messageToCheck.matches(regex)) {

            switch (topic_split[2]) {
                case "HUMIDITY":
                    writeIntoInflux(topic_split[2], "Home WS", "%", messageToCheck);
                    break;

                case "ILLUMINATION":
                    writeIntoInflux(topic_split[2], "Home WS", "lux", messageToCheck);
                    break;

                case "WIND_SPEED":
                    writeIntoInflux(topic_split[2], "Home WS", "km/h", messageToCheck);
                    break;

                case "ACTUAL_TEMPERATURE":
                    writeIntoInflux(topic_split[2], "Home WS", "Â°C", messageToCheck);
                    break;

                default:
                    System.out.println("Error stirb - Stefan Joebstl, 09.05.2020");
                    break;
            }

        }
    }

    public void writeIntoInflux(String nameMeasurement, String tagLocationValue, String tagUnitValue, String fieldValue) {
        try {
            influxDB.write(Point.measurement(nameMeasurement)
                    .tag("location", tagLocationValue)
                    .tag("unit", tagUnitValue)
                    .addField("value", fieldValue)
                    .build());
        } catch (RuntimeException e) {
            System.out.println(e.getCause());
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {
    }
}
